/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author Aprendiz
 */
public class Dias {
    


private int idDias;
private String descripcionDias;

    public int getIdDias() {
        return idDias;
    }

    public void setIdDias(int idDias) {
        this.idDias = idDias;
    }

    public String getDescripcionDias() {
        return descripcionDias;
    }

    public void setDescripcionDias(String descripcionDias) {
        this.descripcionDias = descripcionDias;
    }
}
