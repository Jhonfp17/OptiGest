/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author Aprendiz
 */
public class Asignaciones {
    


private int id_asignaciones;
private String fecha_asignaciones;
private String fecha_devolucion;
private String observaciones;
private String Personal_id_personal;
private String Activos_id_activos;

    public int getId_asignaciones() {
        return id_asignaciones;
    }

    public void setId_asignaciones(int id_asignaciones) {
        this.id_asignaciones = id_asignaciones;
    }

    public String getFecha_asignaciones() {
        return fecha_asignaciones;
    }

    public void setFecha_asignaciones(String fecha_asignaciones) {
        this.fecha_asignaciones = fecha_asignaciones;
    }

    public String getFecha_devolucion() {
        return fecha_devolucion;
    }

    public void setFecha_devolucion(String fecha_devolucion) {
        this.fecha_devolucion = fecha_devolucion;
    }

    public String getObservaciones() {
        return observaciones;
    }

    public void setObservaciones(String observaciones) {
        this.observaciones = observaciones;
    }

    public String getPersonal_id_personal() {
        return Personal_id_personal;
    }

    public void setPersonal_id_personal(String Personal_id_personal) {
        this.Personal_id_personal = Personal_id_personal;
    }

    public String getActivos_id_activos() {
        return Activos_id_activos;
    }

    public void setActivos_id_activos(String Activos_id_activos) {
        this.Activos_id_activos = Activos_id_activos;
    }
      
}
