/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author Aprendiz
 */
public class Estado_Activo {
    

private int idEstado_Activo;
private String descripcion_activo;

    public int getIdEstado_Activo() {
        return idEstado_Activo;
    }

    public void setIdEstado_Activo(int idEstado_Activo) {
        this.idEstado_Activo = idEstado_Activo;
    }

    public String getDescripcion_activo() {
        return descripcion_activo;
    }

    public void setDescripcion_activo(String descripcion_activo) {
        this.descripcion_activo = descripcion_activo;
    }
}
