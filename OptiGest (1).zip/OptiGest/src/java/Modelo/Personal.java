/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author Aprendiz
 */
public class Personal {
    


private int id_personal;
private String nombre;
private String apellidos;
private String identificacion;
private String email;
private String telefono;
private String direccion;
private String clave;
private String observaciones;
private String Documento_id_documento;
private String roles_idroles;
private String Estado_Personal_id_estado;

    public int getId_personal() {
        return id_personal;
    }

    public void setId_personal(int id_personal) {
        this.id_personal = id_personal;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getIdentificacion() {
        return identificacion;
    }

    public void setIdentificacion(String identificacion) {
        this.identificacion = identificacion;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getClave() {
        return clave;
    }

    public void setClave(String clave) {
        this.clave = clave;
    }

    public String getObservaciones() {
        return observaciones;
    }

    public void setObservaciones(String observaciones) {
        this.observaciones = observaciones;
    }

    public String getDocumento_id_documento() {
        return Documento_id_documento;
    }

    public void setDocumento_id_documento(String Documento_id_documento) {
        this.Documento_id_documento = Documento_id_documento;
    }

    public String getRoles_idroles() {
        return roles_idroles;
    }

    public void setRoles_idroles(String roles_idroles) {
        this.roles_idroles = roles_idroles;
    }

    public String getEstado_Personal_id_estado() {
        return Estado_Personal_id_estado;
    }

    public void setEstado_Personal_id_estado(String Estado_Personal_id_estado) {
        this.Estado_Personal_id_estado = Estado_Personal_id_estado;
    }
}
