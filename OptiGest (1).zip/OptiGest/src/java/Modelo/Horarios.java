/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author Aprendiz
 */
public class Horarios {
    


private int id_horarios;
private String fecha_ingreso;
private String fecha_salida;
private String Horarioscod;

    public int getId_horarios() {
        return id_horarios;
    }

    public void setId_horarios(int id_horarios) {
        this.id_horarios = id_horarios;
    }

    public String getFecha_ingreso() {
        return fecha_ingreso;
    }

    public void setFecha_ingreso(String fecha_ingreso) {
        this.fecha_ingreso = fecha_ingreso;
    }

    public String getFecha_salida() {
        return fecha_salida;
    }

    public void setFecha_salida(String fecha_salida) {
        this.fecha_salida = fecha_salida;
    }

    public String getHorarioscod() {
        return Horarioscod;
    }

    public void setHorarioscod(String Horarioscod) {
        this.Horarioscod = Horarioscod;
    }
      
}
