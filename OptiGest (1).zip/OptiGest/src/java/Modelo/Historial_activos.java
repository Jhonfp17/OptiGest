/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author Aprendiz
 */
public class Historial_activos {
    

private int idHistorial_activos;
private String fecha_inicio;
private String fecha_fin;

    public int getIdHistorial_activos() {
        return idHistorial_activos;
    }

    public void setIdHistorial_activos(int idHistorial_activos) {
        this.idHistorial_activos = idHistorial_activos;
    }

    public String getFecha_inicio() {
        return fecha_inicio;
    }

    public void setFecha_inicio(String fecha_inicio) {
        this.fecha_inicio = fecha_inicio;
    }

    public String getFecha_fin() {
        return fecha_fin;
    }

    public void setFecha_fin(String fecha_fin) {
        this.fecha_fin = fecha_fin;
    }
}
