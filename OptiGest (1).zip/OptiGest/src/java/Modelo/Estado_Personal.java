/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author Aprendiz
 */
public class Estado_Personal {
    


private int id_estado;
private String descripcion_estado;

    public int getId_estado() {
        return id_estado;
    }

    public void setId_estado(int id_estado) {
        this.id_estado = id_estado;
    }

    public String getDescriipcion_estado() {
        return descripcion_estado;
    }

    public void setDescriipcion_estado(String descriipcion_estado) {
        this.descripcion_estado = descriipcion_estado;
    }
}