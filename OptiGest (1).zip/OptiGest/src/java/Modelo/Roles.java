/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author USUARIO
 */
public class Roles {
    private int idroles;
    private String descripcion_roles;

    public int getIdroles() {
        return idroles;
    }

    public void setIdroles(int idroles) {
        this.idroles = idroles;
    }

    public String getDescripcion_roles() {
        return descripcion_roles;
    }

    public void setDescripcion_roles(String descripcion_roles) {
        this.descripcion_roles = descripcion_roles;
    }

}
