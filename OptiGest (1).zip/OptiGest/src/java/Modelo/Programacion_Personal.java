/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author Aprendiz
 */
public class Programacion_Personal {
    


private int idProgramacion_Personal;
private String descripcion_progracion;
private String Dias_idDias;
private String Personal_id_personal;
private String Horarios_id_horarios;       

    public int getIdProgramacion_Personal() {
        return idProgramacion_Personal;
    }

    public void setIdProgramacion_Personal(int idProgramacion_Personal) {
        this.idProgramacion_Personal = idProgramacion_Personal;
    }

    public String getDescripcion_progracion() {
        return descripcion_progracion;
    }

    public void setDescripcion_progracion(String descripcion_progracion) {
        this.descripcion_progracion = descripcion_progracion;
    }

    public String getDias_idDias() {
        return Dias_idDias;
    }

    public void setDias_idDias(String Dias_idDias) {
        this.Dias_idDias = Dias_idDias;
    }

    public String getPersonal_id_personal() {
        return Personal_id_personal;
    }

    public void setPersonal_id_personal(String Personal_id_personal) {
        this.Personal_id_personal = Personal_id_personal;
    }

    public String getHorarios_id_horarios() {
        return Horarios_id_horarios;
    }

    public void setHorarios_id_horarios(String Horarios_id_horarios) {
        this.Horarios_id_horarios = Horarios_id_horarios;
    }

}